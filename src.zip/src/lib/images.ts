// Single place for every image path. Files live in /public/images.
// Names are CASE-SENSITIVE on Vercel/Linux. If an extension differs from your file, edit it here.
export const IMG = {
  logo: "public/images/logo.png",
  hero: "public/images/Product-Post.jpg",
  goldGhee: "public/images/",
  silkGhee: "public/images/Product-Post-3.jpeg",
  combo: "public/images/ProductPost-5.jpeg", 

  gallery: [
    "public/images/OnlyProd-whitebg.jpeg",
    "public/images/Product-in-white-bg.jpeg",
    "public/images/Product-in-white-bg-2.jpeg",
    "public/images/Product-in-white-bg-3.jpeg",
    "public/images/white-prod-3.jpeg",
  ],
};
